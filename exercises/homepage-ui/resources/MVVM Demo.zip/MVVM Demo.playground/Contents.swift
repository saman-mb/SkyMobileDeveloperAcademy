import SwiftUI
import XCTest
import Combine

// Low level http networking layer

protocol HTTPNetworkService {
    func load(url: URL, headers: [String: String], body: Data?)
}

class HttpUrlLoader: HTTPNetworkService {
    func load(url: URL, headers: [String: String], body: Data?) {
        // create a network request using the params and then call it and load the response
    }
}

// Home page data domain
enum HomePageTileType: String, Codable {
    
    case hero, portrait, wide, square
}

struct HomePageTile: Codable {

    var title: String?
    var type: HomePageTileType
    var imageUrl: String?
    var trailerUrl: String?
}

struct HomePageSection: Codable {
    let tiles: [HomePageTile]
}

struct HomePageResponse: Codable {
    
    let sections: [HomePageSection]
}

protocol HomePageService {
    
    typealias Completion = (Result<HomePageResponse, Error>) -> Void
    func fetchHomePage(completion: HomePageService.Completion)
}

class HomePageJsonService: HomePageService {
    func fetchHomePage(completion: (Result<HomePageResponse, Error>) -> Void) {
        // fetch the json and handle errors
    }
}

//Home page view model domain, handles logic data retrieval updates and mapping for the home page
protocol ViewModel {
    func update()
}

enum HomePageError: Error {
    case serviceError(Error)
}

class HomePageViewModel: ViewModel, ObservableObject {
    
    private let service: HomePageService
    
    @Published var modelResult: Result<HomePageModel, HomePageError>? = nil
    
    // depedency injection means in the test we can inject in a mock if we want to
    init(service: HomePageService) {
        self.service = service
    }
    
    func update() {
        self.service.fetchHomePage { result in
            switch result {
            case .success(_):
                modelResult = .success(HomePageModel(rails: [])) // <----- we need map the response to a HomePageModel, also consider the the view wants an image not a url, is it ok to load the images on the main thread?
            case .failure(let error):
                modelResult = .failure(.serviceError(error))
            }
        }
    }
}

// View domain handles rendering the UI based on being passed a model that represnts the state of the UI
struct HomePageModel {
    
    let rails: [Rail]
}

struct Rail {
        
    let sectionTitle: String?
    let tiles: [Tile]
}

struct Tile {
    
    enum Template {
        case hero, portrait, wide, square
    }
    
    let template: Template
    let title: String?
    let image: UIImage?
}

struct HomePageView: View {
    
    @ObservedObject var viewModel: HomePageViewModel
    
    var body: some View {
        Text("Hello, World!")
        .onAppear(perform: viewModel.update)
    }
}


// Mocks

class MockViewModel: ViewModel {
    
    func update() {
        // my stub code goes here
    }
}

class MockHTTPNetworkService: HTTPNetworkService {
    
    func load(url: URL, headers: [String : String], body: Data?) {
        // my stub code goes here
    }
}

class MockHomePageService: HomePageService {
    
    func fetchHomePage(completion: (Result<HomePageResponse, Error>) -> Void) {
        // my stub code goes here
    }
}

// Tests

class HomePageServiceTest: XCTestCase {
    
    func testLoad_ValidJsonResponse_HasSuccessResultWithValidResponseModel() {
        
    }
    
    func testLoad_InvalidJsonResponse_HasErrorResultWithWithParsingError() {
        
    }
    
    func testLoad_HTTPCodeIsNot200_HasErrorResultWithWithHttpStatusError() {
        
    }
}
 
class HomePageViewModelTests: XCTestCase {
    
    func testUpdate_CallsHomePageService_HomePageServiceSuccess_ResultIsSuccessWithValidHomeModel() {
        
    }
    
    func testUpdate_CallsHomePageService_HomePageServiceFailure_ResultIsFailureWithServiceError() {
        
    }
}

class HomePageViewTests: XCTestCase {
    
    func testOnAppear_DoesCallUpdateOnViewModel() {
        
    }
}
